Color-Detect
=============

This is a HTML5 and JavaScript-heavy color detector to see what the dominant colors of a given image are.
I used Charles Leifer's technique (http://charlesleifer.com/blog/using-python-and-k-means-to-find-the-dominant-colors-in-images/) to figure the colors out. I haven't tested it thoroughly, but it seems to only work with JPEG images so make sure you upload one of those!
Future work will probably include more contrast-based coloring and more image support.
Right now the browser occasionally crashes too, I think there's an infinite loop not being closed.  But it usually works and that's what matters.

![Screenshot](https://raw.githubusercontent.com/cassidoo/Color-Detect/master/ColorDetectScreenshot.png)
